// console.log(document.cookie)
// document.cookie="name=khushi72628278";
// document.cookie="title=jaiswal09837"
// document.cookie="title=singh82990"
// let key = prompt("Enter your value");
// let value=prompt("Enter your value");
// document.cookie=`${encodeURIComponent(key)}=${encodeURIComponent(value)}`
// console.log(document.cookie)

//local storage
// let key =prompt("Enter key ");
// let value=prompt("Enter value");
// localStorage.setItem(key,value);
// console.log(`The value of key${key} and its value is ${value}`);
// if (key=="red" || key="white"){
//   localStorage.removeItem(key)
// }
var name="priya"
console.log(name)
name="yashika"
console.log(name)

let name="manoj"
name="khushi"
console.log(name)
