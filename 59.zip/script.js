async function khushi(){
  let delhiweather = new Promise((resolve,reject)=>{
    setTimeout(()=>{
      resolve("27 degree")
    },2000)
  })
  let biharweather=new Promise((resolve,reject)=>{
    setTimeout(()=>{
      resolve("20 degree")
    },5000)
  })
  
console.log("Fetching Delhi weather...")
let delhiw= await delhiweather
console.log("Delhi weather is"+ delhiw)
console.log("Fetching bihar weather...")
let biharw= await biharweather
console.log("Delhi weather is"+ biharw)
return[delhiw,biharw];
}

let a =khushi()
a.then((value)=>{
  console.log(value)
})
const cherry= () =>{
  console.log("My Name is Khushi Singh")
}
let b= cherry()