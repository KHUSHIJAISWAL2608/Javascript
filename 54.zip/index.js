console.log("Hello one")
setTimeout(function(){
  console.log("Hello in Two second") 
},3000)
console.log("My Name is helllo three")
let promise= new Promise(function(resolve,reject){
  alert("Hello")
  resolve(56)
})
console.log(promise)