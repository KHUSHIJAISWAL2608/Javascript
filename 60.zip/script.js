setTimeout(()=>{
  console.log("Hacking Wifi......Please wait....")
},2000)

try{
  console.log(khushi)
}
catch(error){
  console.log(error)
}
setTimeout(()=>{
  console.log("Fetching User name and password")
},3000)

setTimeout(()=>{
  console.log("Hacking avinash facebook I'd")
},3000)


setTimeout(()=>{
  console.log("Fetching avinash phone number ")
},4000)