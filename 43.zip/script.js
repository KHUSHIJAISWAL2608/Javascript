let a=document.getElementsByTagName("div")[0]
a.innerHtml=a.innerHtml +'Hello world!';

let div=document.createElement("div");
div.innerHTML='<h1>Hello world!</h1>';
a.appendChild(div);
// a.prepend(div);
a.after(div);
a.before(div);
a.replaceWith(div);
