function load(src){
  let script= document.createElement("script")
  script.src=src;
  script.onLoad=function(){
    console.log("Loaded script with src:" + src)
    callback(src);
  }
    document.body.appendChild(script);                                 
}
// function hello(src){
//   alert('Hello World' + src)
// }
loadScript("https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js");