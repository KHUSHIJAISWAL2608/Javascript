alert("Hello");
document.write("Hello")

let a = setTimeout(function() {
  alert("I am inside of set Timeout")
},2000);
// clearTimeout(a);
// prompt("Do you want to run the setTimeout");
// if("n"==b){
//   clearTimeout(b)
// }
const sum =(a,b) =>{
  console.log("Yes I am Running",  a+b);
}
setTimeout(sum,1000,2,3);
// setInterval(function(){
//   alert("This is khushi singh")
// },3000);
