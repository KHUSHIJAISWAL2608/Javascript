let p1 = new Promise((resolve,reject)=>{
  console.log("Promise is Pending")
  setTimeout(()=>{
    console.log("I am a promise and I am fullfilled")
    resolve(true);
     
  },3000)
})
// console.log(p1);
let p2 = new Promise((resolve,reject)=>{
  console.log("Promise is Pending")
  setTimeout(()=>{
    console.log("I am a promise and I am rejected")
    reject(new Error("I am an error"))
     
  },3000)
})
console.log(p1,p2);
p2.then((value) => {
  console.log(value)
})
}, (error)=>{
  console.log(error)
})
p2.catch((error) => {
  console.log("some error occured in p2")
  
})
