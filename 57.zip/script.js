let p1= new Promise((resolve,reject)=>{
alert("Promise is Resolved");
  resolve(56);
})
p1.then(()=>{
  console.log("Congratulations this promise is now resolved ")
  return new Promise((resolve,reject)=>{
    setTimeout(()=>{
      console.log("inside timeout")
      resolve(36)
    },3000)
  })
}).then((value)=>{
  console.log(value)
  
})
p1.then(()=>{
  console.log("Hurray")
})