let p1= new Promise((resolve , reject )=>{
  setTimeout(()=>{
    console.log("Resolved after 2 seconds ")
    resolve(56)
  },2000)
})


p1.then((value)=>{
  console.log(value)
})
const loadScript=()=>{
  let script=document.createElement("script")
  script.type="text/javascript"
    script.src=src
  document.body.appendChild("script")
}