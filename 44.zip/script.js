first.className="text-dark red";
first.classList.remove("red")
undefined
first.classList.add("red")
undefined
first.classList.toggle("red")
false
first.classList.toggle("red")
true
first.classList.toggle("red")
false
first.classList.toggle("red")
true
