// btn.addEventListener('click',function(e){
//   alert("Hello World!")
// })

// btn.addEventListener('click',function(e){
//   alert("Hello World2!")
// })
let x= function(e){
  alert("Hello1")
}
let y = function(e){
  alert("Hello2")
}

btn.addEventListener('click',x)
btn.addEventListener('click',y)
let a =prompt("Enter your fav num" )
if(a==2){
  btn.removeEventListener('click',x)
}
