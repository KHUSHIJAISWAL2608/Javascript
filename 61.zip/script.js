try{
let age=prompt("Enter your age");
age = Number.parseInt(age)
if (age>120) {
  throw new ReferenceError("AGE IS NOT VALID")
}
}

catch(error) {
  console.log(error)
  console.log(error.name)
  console.log(error.stack)
  console.log(error.message)
}
finally{
  console.log("this will Execute in every condition")
}
//   try{
//   throw new referenceError("Harry is not good");
// }
// catch (error){
//   console.log(error);
//   console.log(error.name)
//   console.log(error.message)
//   console.log(error.stack)
//   // console.log(harry)
// }